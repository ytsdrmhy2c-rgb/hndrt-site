(() => {
 const C = window.HNDRT_CONTENT || {stories:[],notices:[],press:[]};
 const $=(s,c=document)=>c.querySelector(s); const $$=(s,c=document)=>Array.from(c.querySelectorAll(s));
 const clean=(s)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const safeImage=(s)=>typeof s==='string' && s.length<950000 && /^data:image\/(?:jpeg|png|webp);base64,[a-z0-9+/=]+$/i.test(s);
 const saved=(k)=>{try{return JSON.parse(localStorage.getItem(k)||'null')}catch{return null}};
 const stories=()=>[...(saved('hndrt_stories')||[]).filter(s=>s.status!=='draft'),...C.stories];
 const notices=()=>[...(saved('hndrt_notices')||[]).filter(s=>s.status!=='draft'),...C.notices];
 const storyMarkup=(s,i)=>`<a class="story-card" href="story.html?id=${encodeURIComponent(s.id)}"><div class="story-cover ${clean(s.art)}">${safeImage(s.image)?`<img class="story-photo" src="${clean(s.image)}" alt="게시물 대표 사진">`:s.art==='flood'?'<img class="story-photo" src="assets/photos/field-day.jpg" alt="호우 현장 사진 예시">':s.art==='crowd'?'<img class="story-photo" src="assets/photos/field-team.jpg" alt="대응단 대원 단체 사진 예시">':''}<span class="tag">${clean(s.category)}</span><span class="art-num">0${(i%9)+1}</span></div><div class="story-text"><div class="story-meta"><span>${clean(s.date)}</span><span>·</span><span>${clean(s.place)}</span></div><h3>${clean(s.title)}</h3><p>${clean(s.summary)}</p></div></a>`;
 const noteMarkup=(n)=>`<a href="story.html?type=notice&id=${encodeURIComponent(n.id)}" class="notice-item"><div><div class="kind">${clean(n.category)}</div><b>${clean(n.title)}</b></div><time>${clean(n.date)}</time></a>`;
 const pressMarkup=(p)=>`<a href="${clean(p.url)}" target="_blank" rel="noopener noreferrer" class="notice-item"><div><div class="kind">${clean(p.publisher)} · 언론보도</div><b>${clean(p.title)} ↗</b></div><time>${clean(p.date)}</time></a>`;
 const menu=$('.menu-button'),nav=$('.nav'); if(menu&&nav){menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));menu.textContent=open?'✕':'☰';});$$('a',nav).forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')))}
 const homeStories=$('#home-stories');if(homeStories)homeStories.innerHTML=stories().slice(0,3).map(storyMarkup).join('');
 const homeNotices=$('#home-notices');if(homeNotices)homeNotices.innerHTML=notices().slice(0,3).map(noteMarkup).join('')||'<p class="empty-state">등록된 공지가 없습니다.</p>';
 const press=$('#home-press');if(press)press.innerHTML=C.press.slice(0,3).map(pressMarkup).join('');
 const news=$('#news-notices');if(news)news.innerHTML=notices().map(n=>`<div class="article-card"><span class="eyebrow">${clean(n.category)}</span><h3>${clean(n.title)}</h3><time>${clean(n.date)}</time><p>${clean(n.summary)}</p><a class="text-link" href="story.html?type=notice&id=${encodeURIComponent(n.id)}">자세히 읽기 <span class="arrow">↗</span></a></div>`).join('');
 const newsPress=$('#news-press');if(newsPress)newsPress.innerHTML=C.press.map(p=>`<div class="article-card"><span class="eyebrow">MEDIA · ${clean(p.publisher)}</span><h3>${clean(p.title)}</h3><time>${clean(p.date)}</time><p>외부 언론사의 기사로 연결됩니다.</p><a class="text-link" href="${clean(p.url)}" target="_blank" rel="noopener noreferrer">기사 읽기 <span class="arrow">↗</span></a></div>`).join('');
 const archive=$('#archive-grid');
 if(archive){
   const field=$('#archive-search'),sort=$('#archive-sort'),count=$('#archive-count');
   const dateKey=s=>{const m=String(s.date||'').match(/(20\d{2})(?:[^\d]+(\d{1,2}))?/);return m?Number(m[1])*100+Number(m[2]||0):0};
   const draw=()=>{
     const kind=$('.filter.is-active')?.getAttribute('data-kind')||'전체';
     const query=(field?.value||'').trim().toLocaleLowerCase('ko');
     const list=stories().filter(s=>(kind==='전체'||kind===s.category) && (!query||[s.title,s.place,s.summary,s.details,s.category,s.date].join(' ').toLocaleLowerCase('ko').includes(query)));
     list.sort((a,b)=>sort?.value==='old'?dateKey(a)-dateKey(b):dateKey(b)-dateKey(a));
     archive.innerHTML=list.length?list.map(storyMarkup).join(''):'<p class="empty-state">검색 조건에 맞는 현장 기록이 없습니다. 다른 분야나 검색어를 선택해 주세요.</p>';
     if(count)count.textContent=`총 ${list.length}건의 기록`;
   };
   $$('.filter').forEach(b=>b.addEventListener('click',()=>{$$('.filter').forEach(x=>{x.classList.remove('is-active');x.setAttribute('aria-pressed','false')});b.classList.add('is-active');b.setAttribute('aria-pressed','true');draw()}));
   field?.addEventListener('input',draw);sort?.addEventListener('change',draw);draw();
 }
 const article=$('#article-target');
 if(article){
   const q=new URLSearchParams(location.search),isNotice=q.get('type')==='notice';
   const s=(isNotice?notices():stories()).find(x=>x.id===q.get('id'));
   const ret=$('#article-return');if(ret){ret.href=isNotice?'news.html':'archive.html';ret.textContent=isNotice?'← 소식·공지 목록으로':'← 현장 기록 목록으로';}
   if(s){
     document.title=s.title+' | HN-DRT';
     const lines=String(s.details||'').split(/\n+/).filter(Boolean).map(x=>`<p class="article-body-text">${clean(x)}</p>`).join('');
     article.innerHTML=`<article class="story-article"><header class="story-header"><span class="eyebrow">${clean(s.category)}</span><h1>${clean(s.title)}</h1><div class="meta">${clean(s.date)} ${s.place?' · '+clean(s.place):''}</div></header><p class="article-lede">${clean(s.summary)}</p><div class="article-databox"><div><strong>구분</strong><span>${clean(s.category)}</span></div><div><strong>활동 시기</strong><span>${clean(s.date||'확인 중')}</span></div><div><strong>${isNotice?'안내':'활동 지역'}</strong><span>${clean(isNotice?'운영 공지':s.place||'확인 중')}</span></div></div>${safeImage(s.image)?`<img class="article-photo" src="${clean(s.image)}" alt="게시물에 첨부된 현장 사진">`:isNotice?'':'<div class="article-story-placeholder">실제 현장 사진을 공개 전 검수 후 게시합니다.</div>'}<div class="article-body">${lines}</div><div class="notice-emphasis">이 페이지는 홈페이지 제작 시안입니다. 활동 기록과 사진은 정식 공개 전에 원본 자료를 확인할 예정입니다.</div><a class="text-link story-back" href="${isNotice?'news.html':'archive.html'}">← 목록으로 돌아가기</a></article>`;
     const related=$('#related-section'),target=$('#related-grid');
     if(!isNotice && related && target){const others=stories().filter(x=>x.id!==s.id).sort((a,b)=>(a.category===s.category?-1:1)-(b.category===s.category?-1:1)).slice(0,3);if(others.length){target.innerHTML=others.map(storyMarkup).join('');related.hidden=false;}}
   }else article.innerHTML='<div class="story-article"><h1>게시물을 찾을 수 없습니다.</h1><p>주소를 확인하거나 목록에서 게시물을 선택해 주세요.</p><a class="text-link" href="archive.html">현장 기록 보기 ↗</a></div>';
 }
 // A safe, honest local-only editorial prototype. No authentication / no server publication.
 const admin=$('#admin-form');
 if(admin){
   const items=$('#admin-items'),msg=$('#admin-msg'),editId=$('#edit-id');
   const photo=$('#cover-image'),preview=$('#admin-photo-preview');
   const submit=$('#admin-submit'),cancel=$('#admin-cancel'),importer=$('#import-data');
   let retainedImage='';
   const local=(k)=>{const v=saved('hndrt_'+k);return Array.isArray(v)?v:[]};
   const store=(k,data)=>localStorage.setItem('hndrt_'+k,JSON.stringify(data));
   const reset=()=>{admin.reset();editId.value='';retainedImage='';preview.hidden=true;preview.innerHTML='';submit.textContent='게시물 저장';cancel.hidden=true;};
   const notice=(t,err=false)=>{msg.textContent=t;msg.style.color=err?'#ac3b1d':'#315c3e';};
   const list=()=>{
      const html=['stories','notices'].map(k=>local(k).map(s=>`<div class="preview-item"><small>${k==='stories'?'현장 기록':'공지사항'} · ${clean(s.date)} <span class="local-status">${s.status==='draft'?'초안':'사이트 표시'}</span></small><b>${clean(s.title)}</b><div class="editor-actions"><button type="button" data-edit="${clean(s.id)}" data-collection="${k}">수정</button><button class="danger" type="button" data-delete="${clean(s.id)}" data-collection="${k}">삭제</button></div></div>`).join('')).join('');
      items.innerHTML=html||'<p class="small-note">저장된 시연 게시물이 없습니다.</p>';
      $$('[data-edit]',items).forEach(b=>b.addEventListener('click',()=>{
        const k=b.dataset.collection, s=local(k).find(x=>x.id===b.dataset.edit);
        if(!s)return;reset();
        admin.elements['type'].value=k==='notices'?'notice':'story';
        for(const f of ['title','category','date','place','summary','details','status'])if(admin.elements[f])admin.elements[f].value=s[f]||'';
        editId.value=s.id; retainedImage=s.image||'';
        if(retainedImage){preview.hidden=false;preview.innerHTML=`<img src="${clean(retainedImage)}" alt="현재 대표 이미지">`}
        submit.textContent='수정 사항 저장';cancel.hidden=false;
        admin.scrollIntoView({behavior:'smooth',block:'start'});
        notice('게시물을 수정하고 저장하면 이 브라우저의 내용에 반영됩니다.');
      }));
      $$('[data-delete]',items).forEach(b=>b.addEventListener('click',()=>{
        if(!confirm('이 브라우저에서 해당 시연 게시물을 삭제할까요?'))return;
        const k=b.dataset.collection;store(k,local(k).filter(x=>x.id!==b.dataset.delete));
        if(editId.value===b.dataset.delete)reset();list();notice('시연 게시물을 삭제했습니다.');
      }));
   };
   cancel.addEventListener('click',()=>{reset();notice('수정이 취소되었습니다.')});
   photo.addEventListener('change',()=>{
     const f=photo.files?.[0];if(!f){preview.hidden=!retainedImage;return;}
     if(!['image/jpeg','image/png','image/webp'].includes(f.type)||f.size>650*1024){photo.value='';notice('JPG·PNG·WebP 형식, 650KB 이하 이미지만 첨부할 수 있습니다.',true);return;}
     const reader=new FileReader();reader.onload=()=>{preview.hidden=false;preview.innerHTML=`<img src="${reader.result}" alt="새 이미지 미리보기">`};reader.readAsDataURL(f);
   });
   admin.addEventListener('submit',async e=>{
     e.preventDefault();
     const data=new FormData(admin),k=data.get('type')==='notice'?'notices':'stories';
     const title=String(data.get('title')||'').trim();
     const details=String(data.get('details')||'').trim();
     const summary=String(data.get('summary')||'').trim();
     if(!title||!details||!summary){notice('제목·요약·본문을 입력해 주세요.',true);return;}
     let image=retainedImage;
     const f=photo.files?.[0];
     if(f){
       if(!['image/jpeg','image/png','image/webp'].includes(f.type)||f.size>650*1024){notice('650KB 이하 JPG·PNG·WebP 파일이 필요합니다.',true);return;}
       image=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(f)});
     }
     const id=editId.value||('local-'+Date.now());
     const obj={id,category:String(data.get('category')||'활동 기록'),title,date:String(data.get('date')||''),summary,details,place:String(data.get('place')||''),status:String(data.get('status')||'draft'),art:'flood',image};
     try{
       // Editing cross-category content moves it rather than creating an accidental duplicate.
       for(const key of ['stories','notices'])store(key,local(key).filter(x=>x.id!==id));
       store(k,[obj,...local(k)]);
       reset();list();notice('저장했습니다. 사이트 표시는 현재 브라우저에서만 확인할 수 있습니다.');
     }catch(error){notice('저장 공간이 부족하거나 브라우저에서 로컬 저장을 제한했습니다. 이미지 크기를 줄이거나 로컬 서버에서 실행해 주세요.',true)}
   });
   $('#export-data').addEventListener('click',()=>{
     const result={schema:'hndrt-local-preview-v1',savedAt:new Date().toISOString(),stories:local('stories'),notices:local('notices')};
     const url=URL.createObjectURL(new Blob([JSON.stringify(result,null,2)],{type:'application/json'}));
     const a=document.createElement('a');a.href=url;a.download='HN-DRT-local-posts.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);
     notice('로컬 게시물 백업 파일을 만들었습니다.');
   });
   importer?.addEventListener('change',async()=>{
      const file=importer.files?.[0];if(!file)return;
      try{
        if(file.size>4*1024*1024)throw Error('파일이 너무 큽니다.');
        const data=JSON.parse(await file.text());
        if(data.schema!=='hndrt-local-preview-v1'||!Array.isArray(data.stories)||!Array.isArray(data.notices))throw Error('이 시안에서 내보낸 JSON 파일이 아닙니다.');
        if(!confirm('현재 브라우저의 시연 게시물을 백업 내용으로 교체할까요?'))return;
        for(const key of ['stories','notices']){
          const cleanData=data[key].filter(x=>x&&typeof x.id==='string'&&x.id.startsWith('local-')&&typeof x.title==='string'&&typeof x.details==='string').slice(0,100);
          store(key,cleanData);
        }
        reset();list();notice('백업 파일을 불러왔습니다.');
      }catch(err){notice('불러오기에 실패했습니다: '+(err?.message||'파일 오류'),true)}finally{importer.value=''}
   });
   list();
 }
})();
